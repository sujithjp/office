package com.bfsi.ui;

import java.util.List;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.bfsi.dto.PaymentDto;

/*
* The TablePanel class represents a user interface panel for displaying a list of payments in a table.
* It extends JPanel and includes a JTable for displaying payment details.
*/

public class TablePanel extends JPanel
{
	ClientUtils clientUtils = new ClientUtils();
	JTable paymentListTable;
	DefaultTableModel defaultTableModel;
	List<PaymentDto> paymentsList;
	JScrollPane scrollPane;
	List<PaymentDto> searchDtoPaymentList;
	String[][] data;
	
	public TablePanel()
	{
		setLayout(null);
		String[] column1 = {"Payment Id", "Date Created", "Amount Transfer",
                "Transfer Currency", "Submission Method", "Status", "Batch",
                "Customer Batch Ref", "File Name"};
		 
        // Initialize data array with a default size
			data = new String[0][column1.length];
			paymentListTable = new JTable(data, column1);
        
	    	scrollPane = new JScrollPane(paymentListTable);

	        scrollPane.setBounds(0, 0, 1100, 150);
	        fetchPayments();
	        add(scrollPane);

	
	
	}
	
	/*
     * Fetches the list of payments and populates the table model with the payment data.
     */
 	
	public void fetchPayments()
	{
		List<PaymentDto> paymentsList = clientUtils.getAllPayments();
        System.out.println("+++++++++"+paymentsList);
        data = new String[paymentsList.size()][9];
        for (int i = 0; i < paymentsList.size(); i++) {
            PaymentDto payment = paymentsList.get(i);
            data[i][0] =  Long.toString(payment.getPaymentId());
            data[i][1] =  payment.getDate_created().toString();
            data[i][2] = Long.toString(payment.getAmountTransfer()); // Already a string
            data[i][3] = payment.getTransferCurrency();
            data[i][4] = payment.getSubmisionMethod();
            data[i][5] = payment.getStatus(); // Directly assign using toString()
            data[i][6] = Long.toString(payment.getBatchId());
            data[i][7] = payment.getCustomerBatchRef();
            data[i][8] = payment.getFileName();
           
        }
        
        // Update the table model with new data
        
        paymentListTable.setModel(new DefaultTableModel(data, new String[]{
            "Payment Id", "Date Created", "Amount Transfer",
            "Transfer Currency", "Submission Method", "Status", "Batch",
            "Customer Batch Ref", "File Name"
        }));
        
	}
	
	
	public void updateTable(List<PaymentDto> searchPayment) {
	    System.out.println("Updating table with search results: " + searchPayment);
	    if (searchPayment == null || searchPayment.isEmpty()) {
	        System.out.println("No search results found.");
	        return;
	    }

	    data = new String[searchPayment.size()][9];
	    for (int i = 0; i < searchPayment.size(); i++) {
	        PaymentDto payment = searchPayment.get(i);
	        data[i][0] = Long.toString(payment.getPaymentId());
	        data[i][1] = payment.getDate_created().toString();
	        data[i][2] = Long.toString(payment.getAmountTransfer());
	        data[i][3] = payment.getTransferCurrency();
	        data[i][4] = payment.getSubmisionMethod();
	        data[i][5] = payment.getStatus();
	        data[i][6] = Long.toString(payment.getBatchId());
	        data[i][7] = payment.getCustomerBatchRef();
	        data[i][8] = payment.getFileName();
	    }

	    // Update the table model with new data
	    
	    paymentListTable.setModel(new DefaultTableModel(data, new String[]{
	        "Payment Id", "Date Created", "Amount Transfer",
	        "Transfer Currency", "Submission Method", "Status", "Batch",
	        "Customer Batch Ref", "File Name"
	    }));
	    paymentListTable.revalidate();
	    paymentListTable.repaint();
	}


	private void clearTableData(int rowCount) {
        // Clear the table data
        for (int i = 0; i < rowCount; i++) {
            for (int j = 0; j < data[i].length; j++) {
                data[i][j] = "";
            }
        }
    }

	public void updatePayementTable(List<PaymentDto> createPaymentDtoList) {
		 System.out.println("Updating table with search results: " + createPaymentDtoList);
		    if (createPaymentDtoList == null || createPaymentDtoList.isEmpty()) {
		        System.out.println("No search results found.");
		        return;
		    }

		    data = new String[createPaymentDtoList.size()][9];
		    for (int i = 0; i < createPaymentDtoList.size(); i++) {
		        PaymentDto payment = createPaymentDtoList.get(i);
		        data[i][0] = Long.toString(payment.getPaymentId());
		        data[i][1] = payment.getDate_created().toString();
		        data[i][2] = Long.toString(payment.getAmountTransfer());
		        data[i][3] = payment.getTransferCurrency();
		        data[i][4] = payment.getSubmisionMethod();
		        data[i][5] = payment.getStatus();
		        data[i][6] = Long.toString(payment.getBatchId());
		        data[i][7] = payment.getCustomerBatchRef();
		        data[i][8] = payment.getFileName();
		    }

		    // Update the table model with new data
		    
		    paymentListTable.setModel(new DefaultTableModel(data, new String[]{
		        "Payment Id", "Date Created", "Amount Transfer",
		        "Transfer Currency", "Submission Method", "Status", "Batch",
		        "Customer Batch Ref", "File Name"
		    }));
		    paymentListTable.revalidate();
		    paymentListTable.repaint();
		
	}
	
	
}


