package com.bfsi.ui;

/*
 * The Application class serves as the entry point for the application.
 * It initializes and displays the PaymentList and DetailsOfPayment user interfaces.
 */
public class Application
{
	public static void main(String[] args) 
	{
		// Initialize and display the PaymentList UI 
		PaymentList paymentList = new PaymentList();
        paymentList.setVisible(true); 
        
	}

}
