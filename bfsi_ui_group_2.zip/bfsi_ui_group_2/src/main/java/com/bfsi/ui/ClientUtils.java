package com.bfsi.ui;

import java.util.Hashtable;
import java.util.List;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.bfsi.dto.AccountDto;
import com.bfsi.dto.BeneficiaryDto;
import com.bfsi.dto.PaymentDto;
import com.bfsi.dto.PaymentTypeDto;
import com.bfsi.payment.PaymentsCriteriaDTO;
import com.bfsi.sessionfacade.SessionFacadeRemote;

/*
 * The ClientUtils class provides utility methods for interacting with the SessionFacadeRemote.
 * It includes methods for initializing the context, performing JNDI lookup, and retrieving payment lists and payment types.
 */

public class ClientUtils
{
	static List<PaymentDto> paymentList;
	static List<PaymentDto> paymentDtoList;
	static List<PaymentDto> searchPaymentList;

	public ClientUtils()
	{
		
	}
	
	/*
     * The context for JNDI lookup.
     */
	static SessionFacadeRemote sessionFacadeRemote;
	static Context ctx;
	static {
		
	try {
		Hashtable<String, String> ht = new Hashtable<String, String>();
		ht.put(Context.INITIAL_CONTEXT_FACTORY,
				"weblogic.jndi.WLInitialContextFactory");
		ht.put(Context.PROVIDER_URL, "t3://localhost:7001");
		ht.put(Context.SECURITY_PRINCIPAL, "weblogic");
		ht.put(Context.SECURITY_CREDENTIALS, "Weblogic@123");
		
		 ctx = new InitialContext(ht);
		 System.out.println("Initial context created:");
		 
		 String jndiName= "SessionFacadeService";
		 sessionFacadeRemote=(SessionFacadeRemote) ctx
				 .lookup(jndiName);
		 System.out.println("lookup Syccessful");

		
		 System.out.println("Message sent");
		 getAllPayments(); 
		 getBeneficiary();
		 getAllPaymentType();
		

	}
	catch (NamingException e) 
	{
    	System.out.println("A Naming failure occured"+e);
    } 	
	finally {
		try {
		if(ctx!=null)
			ctx.close();
		}catch (Exception e) {
	    	e.printStackTrace();
	    } 	
	}
	}
	
	/**
     * Retrieves all payments. 
     * returns a list of PaymentDto objects
     */
	static List<PaymentDto> getAllPayments()
	{
		if(sessionFacadeRemote == null)
		{
			System.out.println("SessionFacadeRemote is null");
			return null;
		}
		try {
		paymentList =sessionFacadeRemote.getPaymentList();
		System.out.println("Payments fetched succefuully :"+paymentList);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return paymentList;
	
	}

	public static List<PaymentDto> getAllSearchRecord(PaymentsCriteriaDTO dtoObject) {
		   
		if(sessionFacadeRemote == null)
		{
			System.out.println("SessionFacadeRemote is null");
			return null;
		}
		try 
		{
			searchPaymentList = sessionFacadeRemote.searchingPayments(dtoObject);
			System.out.println("Search Payments fetched succefuully :"+searchPaymentList);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return searchPaymentList;
	}
	
	
	/*
     * Retrieves all payment types.
     * 
     * @return a list of PaymentTypeDto objects
     */
	static List<PaymentTypeDto> getAllPaymentType()
	{
		
		if(sessionFacadeRemote == null)
		{
			System.out.println("SessionFacadeRemote is null");
			return null;
		} 

		List<PaymentTypeDto> paymentType =sessionFacadeRemote.getPaymentType(); 
	
		return paymentType;
		
	} 
	static List<AccountDto> getAllAccounts()
	{
		if(sessionFacadeRemote==null)
		{
			System.out.println("SessionFacadeRemote is null"); 
			return null;
		} 
		List<AccountDto> accountsList=sessionFacadeRemote.getAllAccounts();
		return accountsList;
	}
	
	static List<BeneficiaryDto> getBeneficiary()
	{
		if(sessionFacadeRemote==null)
		{
			System.out.println("SessionFacadeRemote is null"); 
			return null;
		} 
		List<BeneficiaryDto> beneficiaryList=sessionFacadeRemote.getBeneficiary();
		return beneficiaryList;
	}
	static void createPayment(PaymentDto dtoObjectCreatePayment)
	{
		if(sessionFacadeRemote==null)
		{
			System.out.println("SessionFacadeRemote is null"); 
			
		} 
		System.out.println("dtoObjectCreatePayment:"+dtoObjectCreatePayment);
		sessionFacadeRemote.createPayment(dtoObjectCreatePayment);
		System.out.println("create payment List");
//		return caretePaymentList;
	}
	
}
