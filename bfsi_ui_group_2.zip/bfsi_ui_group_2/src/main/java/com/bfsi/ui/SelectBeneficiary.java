package com.bfsi.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import com.bfsi.dto.BeneficiaryDto;
import com.bfsi.dto.PaymentTypeDto;
import com.bfsi.ui.PaymentTypeListFrame.PaymentTypeCellRenderer;

public class SelectBeneficiary extends JPanel{

	private JDialog dialog;
	DefaultTableModel defaultTableTypeModel; 
	JLabel selectBeneficiaryLabel,beneficiaryList;
	JButton btnExit;
	List<BeneficiaryDto> beneficiaryDtoList=new ArrayList<BeneficiaryDto>();
	
	public SelectBeneficiary(JDialog dialog) {
		
		// TODO Auto-generated constructor stub
		this.dialog = dialog;

		setPreferredSize(new Dimension(545, 339));
		Container container = this;

		container.setLayout(new BoxLayout(container, BoxLayout.Y_AXIS));
		container.setBackground(Color.white);
		
		Color customColor = new Color(65, 107, 219);
		JPanel topPanel = new JPanel(new BorderLayout());
		topPanel.setBackground(customColor);
		topPanel.setPreferredSize(new Dimension(445, 40));

		// Panel for the left side (Select beneficiary Type label)
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		leftPanel.setOpaque(false);
		selectBeneficiaryLabel = new JLabel("Select Beneficiaries");

		selectBeneficiaryLabel.setFont(new Font("Arial", Font.PLAIN, 16));

		selectBeneficiaryLabel.setForeground(Color.white);
		leftPanel.add(selectBeneficiaryLabel);
		
		// Panel for the right side (Exit button)
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		rightPanel.setOpaque(false);
		btnExit = new JButton("X");
		btnExit.setFont(new Font("Arial", Font.PLAIN, 16));

		btnExit.setContentAreaFilled(false);
		btnExit.setBorderPainted(false);
		btnExit.setFocusPainted(false);
		btnExit.setForeground(Color.white);
//		       
		rightPanel.add(btnExit);
		btnExit.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btnExit.setForeground(Color.RED);
			}

			@Override
			public void mouseExited(MouseEvent e) {
				btnExit.setForeground(Color.white);
			}
		});

		btnExit.addActionListener(e -> dialog.dispose());

		rightPanel.add(btnExit);

		topPanel.add(leftPanel, BorderLayout.WEST);
		topPanel.add(rightPanel, BorderLayout.EAST);

		add(topPanel, BorderLayout.NORTH);

		
		JPanel beneficiaryListPanel = new JPanel(null);
		beneficiaryListPanel.setBackground(Color.white);
		beneficiaryListPanel.setPreferredSize(new Dimension(445, 339));
		beneficiaryListPanel.setBounds(50, 0, 600, 40);
		beneficiaryList = new JLabel("Beneficiary List");
		beneficiaryList.setFont(new Font("Arial", Font.PLAIN, 14));

		beneficiaryList.setBounds(10, 5, 200, 30);
		beneficiaryListPanel.add(beneficiaryList);
		
		defaultTableTypeModel = new DefaultTableModel();
        defaultTableTypeModel = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // All cells are non-editable
            }
        };
        defaultTableTypeModel.setColumnIdentifiers(new String[]{"Beneficiary ID", "Beneficiry Name","Account No","Beneficiary Code","Beneficiary/CDI ref"});

        JTable beneficiaryTable = new JTable(defaultTableTypeModel);
        fetchBeneficiaryData();
        

        JPanel tablePanel = new JPanel(new BorderLayout());
        beneficiaryTable.getColumnModel().getColumn(0)
                .setCellRenderer(new PaymentTypeCellRenderer());
        
       
		
        beneficiaryTable.setRowHeight(30);

		JTableHeader header = beneficiaryTable.getTableHeader();
		header.setFont(new Font("Arial", Font.PLAIN, 14));
		beneficiaryTable.setFont(new Font("Arial", Font.PLAIN, 14));

		JScrollPane scrollPane = new JScrollPane(beneficiaryTable);
		tablePanel.setBounds(15, 40, 510, 200);
		tablePanel.add(scrollPane, BorderLayout.CENTER);

		((JComponent) dialog.getContentPane()).setBorder(BorderFactory.createLineBorder(customColor, 2));
		beneficiaryListPanel.add(tablePanel, BorderLayout.CENTER); 
		container.add(beneficiaryListPanel);
	}
	
	public void fetchBeneficiaryData() 
	{

		beneficiaryDtoList = ClientUtils.getBeneficiary();

		for (BeneficiaryDto beneficiary : beneficiaryDtoList)
		{
			defaultTableTypeModel.addRow(new Object[] {
	    				
					beneficiary.getBeneficiaryId(), beneficiary.getBeneficiaryName(),beneficiary.getAccountNo(),beneficiary.getBeneficiaryCode(),beneficiary.getBeneficiaryCdiRef()

			});

		}

	}
}
