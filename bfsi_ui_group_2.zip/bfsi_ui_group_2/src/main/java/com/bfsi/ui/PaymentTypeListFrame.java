package com.bfsi.ui;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import com.bfsi.dto.PaymentTypeDto;

/*
 * The PaymentTypeListFrame class represents a user interface for displaying a list of payment types.
 * It extends JPanel and includes various UI components such as labels, buttons, and tables.
 */
public class PaymentTypeListFrame extends JPanel 
{
	private JDialog dialog;
	JLabel selectPayment;
	JLabel paymentList;
	JButton btnExit;
	JButton btnClose;
	DefaultTableModel defaultTableTypeModel; 
	List<PaymentTypeDto> paymentTypeList = new ArrayList<PaymentTypeDto>();

	public PaymentTypeListFrame(JDialog dialog,TablePanel createPaymentTable) 
	{
		this.dialog = dialog;

		setPreferredSize(new Dimension(545, 339));
		Container container = this;

		container.setLayout(new BoxLayout(container, BoxLayout.Y_AXIS));
		container.setBackground(Color.white);

		Color customColor = new Color(65, 107, 219);

		JPanel topPanel = new JPanel(new BorderLayout());
		topPanel.setBackground(customColor);
		topPanel.setPreferredSize(new Dimension(445, 40));

		// Panel for the left side (Select Payment Type label)
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		leftPanel.setOpaque(false);
		selectPayment = new JLabel("Select Payment Type");

		selectPayment.setFont(new Font("Arial", Font.PLAIN, 16));

		selectPayment.setForeground(Color.white);
		leftPanel.add(selectPayment);

		// Panel for the right side (Exit button)
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		rightPanel.setOpaque(false);
		btnExit = new JButton("X");
		btnExit.setFont(new Font("Arial", Font.PLAIN, 16));

		btnExit.setContentAreaFilled(false);
		btnExit.setBorderPainted(false);
		btnExit.setFocusPainted(false);
		btnExit.setForeground(Color.white);
//		       
		rightPanel.add(btnExit);
		btnExit.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btnExit.setForeground(Color.RED);
			}

			@Override
			public void mouseExited(MouseEvent e) {
				btnExit.setForeground(Color.white);
			}
		});

		btnExit.addActionListener(e -> dialog.dispose());

		rightPanel.add(btnExit);

		topPanel.add(leftPanel, BorderLayout.WEST);
		topPanel.add(rightPanel, BorderLayout.EAST);

		add(topPanel, BorderLayout.NORTH);

		JPanel paymentListPanel = new JPanel(null);
		paymentListPanel.setBackground(Color.white);
		paymentListPanel.setPreferredSize(new Dimension(445, 339));
		paymentListPanel.setBounds(50, 0, 600, 40);
		paymentList = new JLabel("Payment List");
		paymentList.setFont(new Font("Arial", Font.PLAIN, 14));

		paymentList.setBounds(10, 5, 200, 30);
		paymentListPanel.add(paymentList);
		// Table payment list type -----------------------------------------------
		// Fetch data from the database

        // Table payment list type
        defaultTableTypeModel = new DefaultTableModel();
        defaultTableTypeModel = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // All cells are non-editable
            }
        };
        defaultTableTypeModel.setColumnIdentifiers(new String[]{"paymenttype", "service"});

        JTable paymentListTypeTable = new JTable(defaultTableTypeModel);
        fetchData();

        JPanel tablePanel = new JPanel(new BorderLayout());
        paymentListTypeTable.getColumnModel().getColumn(0)
                .setCellRenderer(new PaymentTypeCellRenderer());
        
        paymentListTypeTable.addMouseListener(new MouseAdapter()
        {
        	public void mouseClicked(MouseEvent e) {
        	    int row = paymentListTypeTable.rowAtPoint(e.getPoint());
        	    int col = paymentListTypeTable.columnAtPoint(e.getPoint());
        	    DetailsOfPayment detailsOfPayment = new DetailsOfPayment(createPaymentTable);
        	    if (col == 0) { // Check if the clicked column is "Payment Type"
        	        Object value = paymentListTypeTable.getValueAt(row, col);
        	        
        	        // Check the type of value and convert if necessary
        	        if (value instanceof Integer)
        	        {
        	            String paymentType = value.toString(); // Convert Integer to String 
        	        	

        	            detailsOfPayment.setPaymentType(paymentType);
        	            detailsOfPayment.setVisible(true);
        	        }
        	        else if (value instanceof String)
        	        {
        	            String paymentType = (String) value; // Cast to String
        	            detailsOfPayment.setPaymentType(paymentType);
        	            detailsOfPayment.setVisible(true);
        	        }
        	        else {
        	            System.err.println("Unexpected value type: " + value.getClass().getName());
        	        }
        	    }
        	}

		}); 
		
		
		paymentListTypeTable.setRowHeight(30);

		JTableHeader header = paymentListTypeTable.getTableHeader();
		header.setFont(new Font("Arial", Font.PLAIN, 14));
		paymentListTypeTable.setFont(new Font("Arial", Font.PLAIN, 14));

		JScrollPane scrollPane = new JScrollPane(paymentListTypeTable);
		tablePanel.setBounds(15, 40, 510, 200);
		tablePanel.add(scrollPane, BorderLayout.CENTER);

		((JComponent) dialog.getContentPane()).setBorder(BorderFactory.createLineBorder(customColor, 2));
		paymentListPanel.add(tablePanel, BorderLayout.CENTER);

		// ---------------------------------close button----------------------

		btnClose = new JButton("Close");
		btnClose.setContentAreaFilled(false);
		btnClose.setBackground(customColor);
		btnClose.setBounds(450, 250, 80, 30);
		       

		btnClose.addMouseListener(new MouseAdapter()
		{
			@Override
			public void mouseEntered(MouseEvent e) 
			{
				btnClose.setForeground(Color.RED);
			}

			@Override
			public void mouseExited(MouseEvent e) {
				btnClose.setForeground(customColor);
			}
		});

		btnClose.addActionListener(e -> dialog.dispose());
		paymentListPanel.add(btnClose);
		add(paymentListPanel, BorderLayout.CENTER);
		container.add(topPanel, BorderLayout.CENTER);
		container.add(paymentListPanel, BorderLayout.NORTH);

	}


	/*
     * Custom cell renderer for the payment type table.
     */
	static class PaymentTypeCellRenderer extends DefaultTableCellRenderer 
	{
		@Override
		public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
				int row, int column) 
		{
			Component cell = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
			cell.setForeground(Color.BLUE);
			cell.setBackground(Color.WHITE);
			return cell;
		}
	}

	/*
     * Fetches data for the payment types and populates the table model.
     */
	public void fetchData() 
	{

		paymentTypeList = ClientUtils.getAllPaymentType();

		for (PaymentTypeDto paymentType : paymentTypeList) 
		{
			defaultTableTypeModel.addRow(new Object[] {
//	    				paymentType.getPaymentId(),
					paymentType.getPaymentType(), paymentType.getService(),

			});

		}

	}
}
