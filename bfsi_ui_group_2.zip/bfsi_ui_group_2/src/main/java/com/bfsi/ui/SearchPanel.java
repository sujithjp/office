package com.bfsi.ui;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.List;
import java.util.Properties;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField.AbstractFormatter;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

import org.jdatepicker.DateModel;
import org.jdatepicker.impl.JDatePanelImpl;
import org.jdatepicker.impl.JDatePickerImpl;
import org.jdatepicker.impl.UtilDateModel;

import com.bfsi.dto.PaymentDto;
import com.bfsi.payment.PaymentsCriteriaDTO;
 
/*
 * The SearchPanel class represents a user interface for searching payment batches.
 * It extends JPanel and includes various UI components such as labels, text fields, combo boxes, and date pickers.
 */
public class SearchPanel extends JPanel
{
 
	/*
     * Date picker for selecting the start date.
     * Date picker for selecting the to date.
     */
    private JDatePickerImpl fromDatePicker;
    private JDatePickerImpl toDatePicker;
    private JTextField txFileName;
    private JTextField txBatchId;
    private JTextField txCustomerBatchRef;
    private JTextField txBeneficiaryName;
    private JComboBox<String> statusComboBox;
    

	List<PaymentDto> paymentDtoList;
	ClientUtils client;
	PaymentsCriteriaDTO dtoObject= new PaymentsCriteriaDTO();
 
    public SearchPanel(TablePanel tablePanel) 
    {
        setLayout(null);
 
		JLabel search =new JLabel("Search Payment Batch");
		this.add(search);
		search.setBounds(10, 10, 180, 15);
	    this.setFont(new Font("Arial", Font.BOLD, 16));
		this.setBorder(new LineBorder(Color.black));
		this.setBackground(Color.WHITE);
		
        JLabel dateCreated = new JLabel();
        dateCreated.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.black), "Date Created"));
        dateCreated.setBounds(20, 39, 390, 90);
        add(dateCreated);
 
        JLabel from = new JLabel("From");
        from.setBounds(20, 15, 50, 30);
        dateCreated.add(from);
 
        fromDatePicker = createDatePicker();
        fromDatePicker.setBounds(25, 40, 150, 30);
        fromDatePicker.setBorder(new LineBorder(Color.BLACK));
        dateCreated.add(fromDatePicker);
 
        JLabel to = new JLabel("TO");
        to.setBounds(230, 55, 50, 30);
        add(to);
 
        toDatePicker = createDatePicker();
        toDatePicker.setBounds(230, 79, 150, 30);
        toDatePicker.setBorder(new LineBorder(Color.BLACK));
        add(toDatePicker);
 
        JLabel status = new JLabel("Status ");
        status.setBounds(430, 50, 110, 30);
        add(status);
        statusComboBox = new JComboBox<>(new String[]{"All", "Pending", "Completed"});
        statusComboBox.setBounds(430, 73, 110, 30);
        add(statusComboBox);
 
        JLabel batchId = new JLabel("Batch Id ");
        batchId.setBounds(565, 50, 80, 30);
        add(batchId);
        txBatchId = new JTextField();
        txBatchId.setBounds(565, 73, 110, 30);
        add(txBatchId);
 
        JLabel customerBatchRef = new JLabel("Customer Batch Ref");
        customerBatchRef.setBounds(695, 50, 145, 30);
        add(customerBatchRef);
        txCustomerBatchRef = new JTextField();
        txCustomerBatchRef.setBounds(700, 73, 110, 30);
        add(txCustomerBatchRef);
        JLabel fileName = new JLabel("File Name");
        fileName.setBounds(835, 50, 80, 30);
        add(fileName);
        txFileName = new JTextField();
        txFileName.setBounds(835, 73, 110, 30);
        add(txFileName);
        JLabel beneficiaryName = new JLabel("Beneficiary Name");
        beneficiaryName.setBounds(970, 50, 120, 30);
        add(beneficiaryName);
        txBeneficiaryName = new JTextField();
        txBeneficiaryName.setBounds(970, 73, 110, 30);
        add(txBeneficiaryName);
 
        JButton searchBtn = new JButton("Search");
        searchBtn.setBounds(20, 160, 100, 30);
        add(searchBtn);
 
     // Initialize client utility
        ClientUtils clientUtils = new ClientUtils();

        // Add action listener to the search button
        searchBtn.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                // Perform search when the button is clicked
                performSearch();
            }

            /**
             * Performs the search based on user inputs and updates the table with the results.
             */
            
            private void performSearch() {
                // Initialize variables
                String status, custBatch;
                LocalDate fromDate, toDate;
                int batchId = 0;
                String fileName, beneficiaryName;

                // Get status from combo box
                status = (String) statusComboBox.getSelectedItem();
                dtoObject.setStatus(status);
                System.out.println("...status..." + status);

                // Get customer batch reference from text field
                custBatch = txCustomerBatchRef.getText();
                dtoObject.setCustomerBatchRef(custBatch);

                // Get batch ID from text field and handle potential number format exception
                String batchIdStr = txBatchId.getText();
                if (batchIdStr != null && !batchIdStr.isEmpty()) {
                    try {
                        batchId = Integer.parseInt(batchIdStr);
                    } catch (NumberFormatException e) {
                        System.err.println("Invalid batch ID: " + batchIdStr);
                    }
                }
                dtoObject.setBatchId(batchId);

                // Get file name from text field
                fileName = txFileName.getText();
                dtoObject.setFileName(fileName);

                // Get from date from date picker
                DateModel<?> fromDateModel = fromDatePicker.getModel();
                if (fromDateModel.getValue() != null) {
                    fromDate = LocalDate.of(fromDateModel.getYear(), fromDateModel.getMonth() + 1, fromDateModel.getDay());
                    dtoObject.setFromDate(fromDate);
                    System.out.println("user select fromdate" + fromDate);
                    System.out.println("user obj" + dtoObject);
                }

                // Get to date from date picker
                DateModel<?> toDateModel = toDatePicker.getModel();
                if (toDateModel.getValue() != null) {
                    toDate = LocalDate.of(toDateModel.getYear(), toDateModel.getMonth() + 1, toDateModel.getDay());
                    dtoObject.setToDate(toDate);
                    System.out.println("user select fromdate" + toDate);
                    System.out.println("user obj" + dtoObject);
                }

                // Perform search using client utility and update table with search results
                List<PaymentDto> paymentDtoList = clientUtils.getAllSearchRecord(dtoObject);
                System.out.println("Search results: " + paymentDtoList);
                tablePanel.updateTable(paymentDtoList);
            }
        });

 
        JButton resetBtn = new JButton("Reset");
        resetBtn.setBounds(135, 160, 100, 30);
        add(resetBtn);
        
        resetBtn.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                resetForm();
            }
            
 
            /*
             * Resets the form fields to their default values.
             */
            private void resetForm()
            {
                txBatchId.setText("");
                txCustomerBatchRef.setText("");
                txFileName.setText("");
                txBeneficiaryName.setText("");
                fromDatePicker.getModel().setValue(null);
                toDatePicker.getModel().setValue(null);
                statusComboBox.setSelectedIndex(0);
            }
        });        
    }
 
    
    /*
     * Creates and returns a JDatePickerImpl component.
     * This method sets up a date picker with a specific date format and custom text for today, month, and year.
     * @return a JDatePickerImpl component configured with the specified properties and date format
     */
    private JDatePickerImpl createDatePicker()
    {
        UtilDateModel model = new UtilDateModel();
        Properties properties = new Properties();
        properties.put("text.today", "Today");
        properties.put("text.month", "Month");
        properties.put("text.year", "Year");
 
        JDatePanelImpl datePanel = new JDatePanelImpl(model, properties);
        JDatePickerImpl datePicker = new JDatePickerImpl(datePanel, new AbstractFormatter()
        {
            private String datePattern = "yyyy-MM-dd";
            private SimpleDateFormat dateFormatter = new SimpleDateFormat(datePattern);
 
            @Override
            public Object stringToValue(String text) throws ParseException
            {
                return dateFormatter.parse(text);
            }
 
            @Override
            public String valueToString(Object value) throws ParseException
            {
                if (value != null)
                {
                    Calendar cal = (Calendar) value;
                    return dateFormatter.format(cal.getTime());
                }
                return "";
            }
        });
 
        return datePicker;
    }
}
