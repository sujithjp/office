package com.bfsi.ui;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dialog;
import java.awt.Font;
import java.awt.Window;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.*;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.border.LineBorder;

import com.bfsi.sessionfacade.SessionFacadeRemote;

/*
 * The PaymentList class represents a user interface for displaying a list of payments.
 * It extends JFrame and includes various UI components such as labels, buttons, and panels.
 */
public class PaymentList extends JFrame
{
	JLabel payments_list;
	JButton btnCreatePayment;
	
	public PaymentList()
	{   
		
		setSize(2000,2000);
		Container c=this.getContentPane();
		 setTitle("Business Online");
		c.setBackground(Color.WHITE);
		 
		/*
	     * Label for displaying the title "Payment List".
	     * Button for creating a new payment.
	     */
	     payments_list = new JLabel("Payment List");
	     btnCreatePayment = new JButton("Create Payment");
	     this.setLayout(null);
	     
	     payments_list.setBounds(500, 10, 300, 50); // x, y, width, height
	     payments_list.setFont(new Font("Georgia", Font.BOLD, 20));
	     btnCreatePayment.setBounds(100, 60, 200, 30);

//	     btnCreatePayment.addActionListener(e -> {
//	         // Create and show the popup frame with SearchPanel
////	 		 new PaymentTypeListFrame();  
//	    	 JDialog dialog = new JDialog((Window) null, Dialog.ModalityType.MODELESS);
//	 	        SwingUtilities.invokeLater(() -> new PaymentTypeListFrame(dialog));
//
//	     });
	     TablePanel tablePanel = new TablePanel();
	     tablePanel.setBounds(70, 400, 1100, 150);
	    

	     System.out.println("Table found........." + tablePanel);
	     btnCreatePayment.addActionListener(e -> {
	    	    SwingUtilities.invokeLater(() -> {
	    	        // Create a new JDialog with a custom title bar
	    	        JDialog dialog = new JDialog((Window) null, Dialog.ModalityType.MODELESS);

	    	        dialog.setUndecorated(true); // Remove the default title bar

	    	        // Create an instance of PaymentTypeListFrame 
	    	        
	    	        PaymentTypeListFrame paymentTypeFrame = new PaymentTypeListFrame(dialog,tablePanel);

//	    	         Add the PaymentTypeFrame to the dialog
	    	        dialog.getContentPane().add(paymentTypeFrame);

//	    	         Set dialog properties
	    	        dialog.pack();
	    	        dialog.setLocationRelativeTo(null);
	    	        dialog.setVisible(true);
	    	    });
	    	});

	     c.add(payments_list);
	     c.add(btnCreatePayment);

	    // setResizable(false);
	     c.add(tablePanel);
	     
	   
		 JPanel searchPanel= new SearchPanel(tablePanel);
	     searchPanel.setBounds(70,120,1100,250);
	     searchPanel.setBorder(new LineBorder(Color.BLACK));
	     searchPanel.setBackground(Color.WHITE);
	     c.add(searchPanel);
	     
	     c.revalidate();
	     c.repaint();
	     
		this.addWindowListener(new WindowAdapter() 
		{
			public void windowClosing(WindowEvent event) 
			{
				System.exit(0);
			}
		});

		
    }


}
