package com.bfsi.ui;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;

import com.bfsi.dto.AccountDto;

public class SelectAccountFrame extends JPanel {
    private JDialog dialog;
    JLabel selectAccount; 
    JLabel accountLabel;
    JButton btnExit;
    JButton btnClose, addSelected;
    DefaultTableModel accountTableModel;
    DetailsOfPayment detailsOfPayment;
    List<AccountDto> accountList = new ArrayList<AccountDto>();
    List<Object> rowPassedData;
    Object value;
    public SelectAccountFrame(Dialog dialog,final DetailsOfPayment parent) {
        this.dialog = (JDialog) dialog; 

        dialog.setUndecorated(true); // Remove the default title bar
        setPreferredSize(new Dimension(790, 339));
        dialog.setPreferredSize(new Dimension(790, 339));
        dialog.pack();
        dialog.setLocationRelativeTo(null);

        Container container = this;
        container.setLayout(new BoxLayout(container, BoxLayout.Y_AXIS));
        container.setBackground(Color.white);

        Color customColor = new Color(65, 107, 219);

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(customColor);
        topPanel.setPreferredSize(new Dimension(445, 40));

        // Panel for the left side (Select Payment Type label)
        JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        leftPanel.setOpaque(false);

        selectAccount = new JLabel("Select Account");
        selectAccount.setFont(new Font("Arial", Font.PLAIN, 16));
        selectAccount.setForeground(Color.white);

        leftPanel.add(selectAccount);

        // Panel for the right side (Exit button)
        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        rightPanel.setOpaque(false);

        btnExit = new JButton("X");
        btnExit.setFont(new Font("Arial", Font.PLAIN, 16));
        btnExit.setContentAreaFilled(false);
        btnExit.setBorderPainted(false);
        btnExit.setFocusPainted(false);
        btnExit.setForeground(Color.white);

        rightPanel.add(btnExit);
        btnExit.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btnExit.setForeground(Color.RED);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                btnExit.setForeground(Color.white);
            }
        });

        btnExit.addActionListener(e -> dialog.dispose());

        topPanel.add(leftPanel, BorderLayout.WEST);
        topPanel.add(rightPanel, BorderLayout.EAST);
        add(topPanel, BorderLayout.NORTH);

        JPanel AccountsPanel = new JPanel(null);
        AccountsPanel.setBackground(Color.white);
        AccountsPanel.setPreferredSize(new Dimension(445, 339));
        AccountsPanel.setBounds(50, 0, 600, 40);
        accountLabel = new JLabel("List of associated accounts");
        accountLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        accountLabel.setBounds(10, 5, 200, 30);
        AccountsPanel.add(accountLabel);

        accountTableModel = new DefaultTableModel();
        accountTableModel.setColumnIdentifiers(new String[]{"accountno", "BIC(swift)", "sortcode", "currency", "accountName", "Country/Region", "Base currency", "IBAN"});

        JTable accountListTable = new JTable(accountTableModel);
        fetchAccountList();

        JPanel tablePanel = new JPanel(new BorderLayout());
        accountListTable.getColumnModel().getColumn(0)
                .setCellRenderer(new PaymentTypeCellRenderer());
        
        accountListTable.setRowHeight(30);

        JTableHeader header = accountListTable.getTableHeader();
        header.setFont(new Font("Arial", Font.PLAIN, 14));
        accountListTable.setFont(new Font("Arial", Font.PLAIN, 14));

        tablePanel.setBounds(15, 40, 760, 200);

        ((JComponent) ((JDialog) dialog).getContentPane()).setBorder(BorderFactory.createLineBorder(customColor, 2));
        AccountsPanel.add(tablePanel, BorderLayout.CENTER);

        btnClose = new JButton("CLOSE");
        btnClose.setContentAreaFilled(false);
        btnClose.setBackground(customColor);
        btnClose.setBounds(520, 250, 80, 30);

        addSelected = new JButton("ADD SELECTED");
        addSelected.setContentAreaFilled(false);
        addSelected.setBackground(customColor);
        addSelected.setBounds(100, 250, 150, 30);

        btnClose.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btnClose.setForeground(Color.BLACK);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                btnClose.setForeground(customColor);
            }
        });

        addSelected.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                addSelected.setForeground(Color.BLACK);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                addSelected.setForeground(customColor);
            }
                 
        }); 
  

        accountListTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 1) {
                    int selectedRow = accountListTable.getSelectedRow();
                    if (selectedRow != -1) { 
                        List<String> rowData = new ArrayList<>();
                        for (int col = 0; col < accountTableModel.getColumnCount(); col++) {
                            Object value = accountTableModel.getValueAt(selectedRow, col);
                            rowData.add(value != null ? value.toString() : ""); // Convert to String using toString() method
                        }
                        parent.setTextFieldData(rowData);
                        dialog.dispose();
                    }
                }
            }
        });

       
        JScrollPane scrollPane = new JScrollPane(accountListTable);
        tablePanel.add(scrollPane, BorderLayout.CENTER);

        btnClose.addActionListener(e -> dialog.dispose());
        AccountsPanel.add(btnClose);
        AccountsPanel.add(addSelected);

        add(AccountsPanel, BorderLayout.CENTER);
        container.add(topPanel, BorderLayout.CENTER);
        container.add(AccountsPanel, BorderLayout.NORTH);
        dialog.add(container);
        dialog.setVisible(true);
    }

    static class PaymentTypeCellRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
                                                       int row, int column) {
            Component cell = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            cell.setForeground(Color.BLUE);
            cell.setBackground(Color.WHITE);
            return cell;
        }
    }

    public void fetchAccountList() {
        accountList = ClientUtils.getAllAccounts();
        for (AccountDto account : accountList) {
            accountTableModel.addRow(new Object[]{
                    account.getAccNo(),
                    account.getBICCode(),
                    account.getSortCode(),
                    account.getCurrency(),
                    account.getAccountName(),
                    account.getCountry(),
                    account.getBaseCurrency(),
                    account.getIbanNo()
            });
        }
    }

}