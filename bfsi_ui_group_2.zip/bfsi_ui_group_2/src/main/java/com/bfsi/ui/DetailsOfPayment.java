package com.bfsi.ui;

import java.awt.Color;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dialog;
import java.awt.Font;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Properties;
import java.time.LocalDate;
import javax.jms.ConnectionFactory;
import javax.jms.JMSContext;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.naming.InitialContext;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFormattedTextField.AbstractFormatter;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.border.LineBorder;

import org.jdatepicker.DateModel;
import org.jdatepicker.impl.JDatePanelImpl;
import org.jdatepicker.impl.JDatePickerImpl;
import org.jdatepicker.impl.UtilDateModel;


import com.bfsi.dto.PaymentDto;
import com.bfsi.payment.PaymentsCriteriaDTO;

/*
 * The DetailsOfPayment class represents a user interface for creating and viewing payment details.
 * It extends JFrame and includes various UI components such as labels, text fields, combo boxes, and date pickers.
 */





public class DetailsOfPayment extends JFrame
{
	JLabel paymentlabel,innerlabel,valueDateLabel,detailsofPayment,paymentTypeLabel,serviceLevelLabel,chargesPaidByLabel,positionOptionLabel,fundingOptionLabel;
	JLabel payFrom,payTo,accountNumberLabel,ibanLabel,transferCurrencyLabel,debitAmountLabel,debitReferenceLabel;
	JTextField paymentTypeField,valueDateField,accountNumberField,ibanField,debitAmountField,debitReferenceField;
	JComboBox<String> serviceLavelField,chargesPaidByField,positionOptionField,fundingoptionField,transferCurrencyField;
    private JDatePickerImpl valueDatePicker;
    private String datafield;
    Object rowRecivedData;
    PaymentDto dtoObjectCreatePayment= new PaymentDto();
    ClientUtils client;
    public DetailsOfPayment(TablePanel createPaymentTable)
	{
		setLayout(null);
		setSize(2000,2000);
		Container c=this.getContentPane();
		setTitle("Business Online");
		c.setBackground(Color.WHITE);
		JLabel headingLabel=new JLabel("Create Payment");
		headingLabel.setBounds(30, 10, 300, 50);
		headingLabel.setFont(new Font("Georgia", Font.BOLD, 18));
		c.add(headingLabel);
		//--------------------------------------------
		JPanel warningPanel=new JPanel();
		warningPanel.setBounds(30, 60, 30, 30);
		warningPanel.setBorder(new LineBorder(Color.orange,4));
		warningPanel.setBackground(Color.yellow);
		innerlabel=new JLabel("!");
		innerlabel.setFont(new Font("Georgia", Font.BOLD, 17));
		paymentlabel = new JLabel("Payments to 3rd party banks must be submitted prior to the cut off time for the debit and credit to be proccessed on the value date");
		paymentlabel.setBounds(60,60,1150,30);
		paymentlabel.setBorder(new LineBorder(Color.ORANGE,4));
		c.add(paymentlabel);
		warningPanel.add(innerlabel);
		c.setBackground(Color.white);
		c.add(warningPanel);
		
		//---------------------------------------------
		this.setLayout(null);
		JLabel detailspayment =new JLabel();
		this.add(detailspayment);
		detailspayment.setBounds(20, 130, 1200, 120);
	    this.setFont(new Font("Arial", Font.BOLD, 20));
	    detailspayment.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.black), "Details of Payment"));
		this.setBackground(Color.WHITE);
		
		//---------------------------------------------
		paymentTypeLabel=new JLabel("Payment Type");
		paymentTypeLabel.setBounds(60, 150, 150, 50);
		paymentTypeLabel.setFont(new Font("Raleway", Font.BOLD, 12));
		
		
//		paymentTypeField=new JTextField(DetailsOfPayment);
		paymentTypeField=new JTextField();

		paymentTypeField.setBounds(50, 190, 150, 25);
		paymentTypeField.setBackground(Color.LIGHT_GRAY);
		paymentTypeField.setEnabled(true);//field is enable 
		paymentTypeField.setEditable(false); 
		paymentTypeField.setFocusable(false);
		c.add(paymentTypeField);
		c.add(paymentTypeLabel);
		
		//---------------------------------------------
		valueDateLabel=new JLabel("Value Date");
		valueDateLabel.setBounds(260, 150, 150, 50);
		valueDateLabel.setFont(new Font("Raleway", Font.BOLD, 12));
		c.add(valueDateLabel);
		
		valueDatePicker = createDatePicker();
		valueDatePicker.setBounds(250, 190, 150, 25);
		valueDatePicker.setBorder(new LineBorder(Color.BLACK));
		//detailspayment.add(valueDatePicker);
		c.add(valueDatePicker);
		
		//-----------------------------------------------
		serviceLevelLabel=new JLabel("Service Level");
		serviceLevelLabel.setBounds(460, 150, 150, 50);
		serviceLevelLabel.setFont(new Font("Raleway", Font.BOLD, 12));
		String[] statusOptions = {"Normal", "Pending", "Completed"};
		c.add(serviceLevelLabel);
		
		serviceLavelField = new JComboBox(statusOptions);
		serviceLavelField.setBounds(450, 190, 150, 25);
		serviceLavelField.setBorder(new LineBorder(Color.black,2,true));
		serviceLavelField.setBackground(Color.LIGHT_GRAY);
		serviceLavelField.setEnabled(false);
		c.add(serviceLavelField);
	
		//--------------------------------------------------
		chargesPaidByLabel=new JLabel("Charges Paid By");
		chargesPaidByLabel.setBounds(660, 150, 150, 50);
		chargesPaidByLabel.setFont(new Font("Raleway", Font.BOLD, 12));
		String[] statusOptions1 = {"Own", "Family", "Company"};
		c.add(chargesPaidByLabel);
		
		chargesPaidByField=new JComboBox(statusOptions1);
		chargesPaidByField.setBounds(650, 190, 150, 25);
		chargesPaidByField.setBorder(new LineBorder(Color.black,2,true));
		chargesPaidByField.setBackground(Color.lightGray);
		chargesPaidByField.setEnabled(false);
		c.add(chargesPaidByField);
	
		//--------------------------------------------------
		positionOptionLabel=new JLabel("Position Option");
		positionOptionLabel.setBounds(860, 150, 150, 50);
		positionOptionLabel.setFont(new Font("Raleway", Font.BOLD, 12));
		String[] statusOptions2 = {" ", " ", " "};
		c.add(positionOptionLabel);

		positionOptionField=new JComboBox(statusOptions2);
		positionOptionField.setBounds(850, 190, 150, 25);
		positionOptionField.setBorder(new LineBorder(Color.black,2,true));
		positionOptionField.setBackground(Color.lightGray);
		positionOptionField.setEnabled(false);
		c.add(positionOptionField);
	
		//-----------------------------------------------------
		
		fundingOptionLabel=new JLabel("Funding Option");
		fundingOptionLabel.setBounds(1060, 150, 150, 50);
		fundingOptionLabel.setFont(new Font("Raleway", Font.BOLD, 12));
		String[] statusOptions3 = {"Available Funds", "Pending Funds","Submitted Funds"};
		c.add(fundingOptionLabel);

		fundingoptionField=new JComboBox(statusOptions3);
		fundingoptionField.setBounds(1050, 190, 150, 25);
		fundingoptionField.setBorder(new LineBorder(Color.black,2,true));
		fundingoptionField.setBackground(Color.lightGray);
		fundingoptionField.setEnabled(false);
		c.add(fundingoptionField);	

		//******PAY FROM************************************

		payFrom = new JLabel();
		payFrom.setBounds(20, 270, 1200, 150);
		this.setFont(new Font("Arial", Font.BOLD, 20));
		payFrom.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.black), "Pay From"));
		payFrom.setBackground(Color.white);
		c.add(payFrom); 
		
		//------------------------------------- 

		accountNumberLabel=new JLabel("Account Number");
        accountNumberLabel.setBounds(60, 290, 160, 50);
        accountNumberLabel.setFont(new Font("Raleway", Font.BOLD, 12));

		accountNumberField=new JTextField(datafield);
		accountNumberField.setBounds(50, 330, 150, 25);
		accountNumberField.setBorder(new LineBorder(Color.black,2,true));
		accountNumberField.setBackground(Color.LIGHT_GRAY);
		accountNumberField.setEnabled(true);//field is disable
		c.add(accountNumberField);
		c.add(accountNumberLabel);
		
		//----------------------------------------
		JLabel linkLabel=new JLabel("<html><a href=' '>Select Account</a></html>");
		linkLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
		linkLabel.setBounds(220, 320, 180, 50);
		linkLabel.setFont(new Font("Raleway", Font.PLAIN, 13));
		
		linkLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                System.out.println("Label clicked!");  
                JDialog dialog = new JDialog((Window) null, Dialog.ModalityType.MODELESS);
//               
			

        dialog.setUndecorated(true); // Remove the default title bar

        SelectAccountFrame selectAccountDialogBox = new SelectAccountFrame(dialog, DetailsOfPayment.this); // Pass the existing instance as listener
        dialog.setContentPane(selectAccountDialogBox);
            }
        }); 
		
		c.add(linkLabel); 

		//-------------------------------------------
		ibanLabel=new JLabel("IBAN");
		ibanLabel.setBounds(370, 290, 180, 50);
		ibanLabel.setFont(new Font("Raleway", Font.BOLD, 12));
		ibanField=new JTextField(20);
		ibanField.setBounds(360, 330, 150, 25);
		ibanField.setBorder(new LineBorder(Color.black,2,true));
		ibanField.setBackground(Color.LIGHT_GRAY);
		ibanField.setEnabled(true);//field is disable
		c.add(ibanLabel);
		c.add(ibanField);
		
		//-----------------------------------------------
		transferCurrencyLabel=new JLabel("Transfer Currency");
		transferCurrencyLabel.setBounds(550, 290, 180, 50);
		transferCurrencyLabel.setFont(new Font("Raleway", Font.BOLD, 12));
		String[] statusOptions4 = {"AFN", "AUD","CAD","INR","CDF","USD","GBP"};
		transferCurrencyField=new JComboBox(statusOptions4);
		transferCurrencyField.setBounds(550, 330, 150, 25);
		transferCurrencyField.setBorder(new LineBorder(Color.black,2,true));
		//positionOptionField.setBackground(Color.lightGray);
		transferCurrencyField.setEnabled(true);
		c.add(transferCurrencyLabel);
		c.add(transferCurrencyField);	
		
		//------------------------------------------
		
		debitAmountLabel=new JLabel("Debit Amount");
		debitAmountLabel.setBounds(750, 290, 180, 50);
		debitAmountLabel.setFont(new Font("Raleway", Font.BOLD, 12));
		debitAmountField=new JTextField(20);
		debitAmountField.setBounds(750, 330, 150, 25);
		debitAmountField.setBorder(new LineBorder(Color.black,2,true));
		debitAmountField.setBackground(Color.LIGHT_GRAY);
		debitAmountField.setEnabled(true);//field is disable
		c.add(debitAmountLabel);
		c.add(debitAmountField);
		
		//-----------------------------------------------------
		
		debitReferenceLabel=new JLabel("Debit Reference");
		debitReferenceLabel.setBounds(960, 290, 180, 50);
		debitReferenceLabel.setFont(new Font("Raleway", Font.BOLD, 12));
		debitReferenceField=new JTextField(20);
		debitReferenceField.setBounds(950, 330, 150, 25);
		debitReferenceField.setBorder(new LineBorder(Color.black,2,true));
		debitReferenceField.setBackground(Color.LIGHT_GRAY);
		debitReferenceField.setEnabled(true);//field is disable
		c.add(debitReferenceLabel);
		c.add(debitReferenceField);
				
		c.add(payFrom);
	    setVisible(true);
	   //-----------------------------------------
	    
	    JButton showAvailableBalance = new JButton("Show Available Balance");
	    showAvailableBalance.setBounds(50, 375, 180, 25);
	    showAvailableBalance.setBackground(Color.LIGHT_GRAY);
	    showAvailableBalance.setFont(new Font("Raleway", Font.BOLD, 12));
	    showAvailableBalance.setForeground(Color.BLACK);
        c.add(showAvailableBalance);
        
      //******PAY To************************************

      		payTo = new JLabel();
      		payTo.setBounds(20, 440, 1200, 150);
      		this.setFont(new Font("Arial", Font.BOLD, 20));
      		payTo.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.black), "Pay To"));
      		payTo.setBackground(Color.white);
      		c.add(payTo); 
      	//----------------------------------------


          	JButton selectBeneficiaryButton = new JButton("SELECT BENEFICIARY");
          	// selectBeneficiaryButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
          	selectBeneficiaryButton.setBounds(60, 470, 180, 25);
          	selectBeneficiaryButton.setFont(new Font("Raleway", Font.BOLD, 12));
          	selectBeneficiaryButton.addActionListener(e -> {
    	    	    SwingUtilities.invokeLater(() -> {
    	    	        // Create a new JDialog with a custom title bar
    	    	        JDialog dialog = new JDialog((Window) null, Dialog.ModalityType.MODELESS);

    	    	        dialog.setUndecorated(true); // Remove the default title bar

    	    	        // Create an instance of PaymentTypeListFrame 
    	    	        
    	    	        SelectBeneficiary selectBeneficiary = new SelectBeneficiary(dialog);

    	    	        // Add the PaymentTypeFrame to the dialog
    	    	        dialog.getContentPane().add(selectBeneficiary);

    	    	        // Set dialog properties
    	    	        dialog.pack();
    	    	        dialog.setLocationRelativeTo(null);
    	    	        dialog.setVisible(true);
    	    	    });
    	    	});
          	c.add(selectBeneficiaryButton);
      	JButton adHocBeneficiaryButton = new JButton("ADD AD-HOC BENEFICIARY");
      	// adHocBeneficiaryButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
      	adHocBeneficiaryButton.setBounds(340, 470, 210, 25);
      	adHocBeneficiaryButton.setFont(new Font("Raleway", Font.BOLD, 12));
      	c.add(adHocBeneficiaryButton);

      	JButton submitButton = new JButton("Submit");
      	submitButton.setBounds(60, 600, 150, 30);
      	submitButton.setBackground(Color.LIGHT_GRAY);
      	submitButton.setFont(new Font("Raleway", Font.BOLD, 13));
      	submitButton.setForeground(Color.BLUE);
      	c.add(submitButton);


      	 // Initialize client utility
        ClientUtils clientUtils = new ClientUtils();
      	 
        submitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    int debitAmount = 0;
                    String transferAmount = debitAmountField.getText();
                    String transferCurrency = (String) transferCurrencyField.getSelectedItem();
                    DateModel<?> date = valueDatePicker.getModel();

                    if (date.getValue() != null) {
                        LocalDate dateCreated = LocalDate.of(date.getYear(), date.getMonth(), date.getDay());
                        dtoObjectCreatePayment.setDate_created(dateCreated);
                    }

                    if (transferAmount != null && !transferAmount.isEmpty()) {
                        try {
                            debitAmount = Integer.parseInt(transferAmount);
                        } catch (NumberFormatException e1) {
                            System.err.println("Invalid amount: " + transferAmount);
                        }
                    }

                    dtoObjectCreatePayment.setAmountTransfer(debitAmount);
                    dtoObjectCreatePayment.setTransferCurrency(transferCurrency);

                    clientUtils.createPayment(dtoObjectCreatePayment);
//                    System.out.println("Search results: " + createPaymentDtoList);
//                    createPaymentTable.updatePayementTable(createPaymentDtoList);

                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });
      	////////////////---------------------
      	JButton ResetButton = new JButton("Reset");
      	ResetButton.setBounds(850, 600, 150, 30);
      	ResetButton.setBackground(Color.LIGHT_GRAY);
      	ResetButton.setFont(new Font("Raleway", Font.BOLD, 13));
      	ResetButton.setForeground(Color.BLUE);
      	c.add(ResetButton);

      	JButton CancelButton = new JButton("Cancel");
      	CancelButton.setBounds(1050, 600, 150, 30);
      	CancelButton.setBackground(Color.LIGHT_GRAY);
      	CancelButton.setFont(new Font("Raleway", Font.BOLD, 13));
      	CancelButton.setForeground(Color.BLUE);
    	c.add(CancelButton); 
      	
      	
      	CancelButton.addActionListener(e -> {
      	    Window window = SwingUtilities.getWindowAncestor(CancelButton);
      	    if (window != null) {
      	        window.dispose();
      	    }
      	});
      	
 
	
	}  
    

    
    public void setPaymentType(String paymentType) {
        paymentTypeField.setText(paymentType);
    }  
   
   
    public void setTextFieldData(List<String> data) {
    	{
    	    if (!data.isEmpty()) {
    	        // Store the first value of the list in the text field
    	        accountNumberField.setText(data.get(0));  
    	        ibanField.setText(data.get(7));
    	        
    	    } else {
    	        accountNumberField.setText(""); 
    	    

    	    }
    } }
    
  
	/*
     * Creates and returns a date picker component. 
     * @return a JDatePickerImpl object
     */
	private JDatePickerImpl createDatePicker()
    {
        UtilDateModel model = new UtilDateModel();
        Properties properties = new Properties();
        properties.put("text.today", "Today");
        properties.put("text.month", "Month");
        properties.put("text.year", "Year");
 
        JDatePanelImpl datePanel = new JDatePanelImpl(model, properties);
        JDatePickerImpl datePicker = new JDatePickerImpl(datePanel, new AbstractFormatter()
        {
            private String datePattern = "yyyy-MM-dd";
            private SimpleDateFormat dateFormatter = new SimpleDateFormat(datePattern);
 
            @Override
            public Object stringToValue(String text) throws ParseException
            {
                return dateFormatter.parse(text);
            }
 
            @Override
            public String valueToString(Object value) throws ParseException
            {
                if (value != null)
                {
                    Calendar cal = (Calendar) value;
                    return dateFormatter.format(cal.getTime());
                }
                return "";
            }
        });
 
        return datePicker;
    }

	

}


