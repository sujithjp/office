package com.bfsi.dto;

import java.io.Serializable;

import javax.persistence.Column;


/* It seperates data representation from business logic
 * This class have account table fields
 * 
 */
public class AccountDto implements Serializable// export nahi karu na 
{
	private static final long serialVersionUID = 4136665426450020395L;
	private int accNo; 
	private String BICCode;
	private int sortCode; 
	private String currency; 
	private String accountName;
	private String country;
	private String baseCurrency;
	private String ibanNo;
	/*
     * Constructs a new AccountDto with the specified details.
     *
     * @param accNo the unique identifier for the account
     * @param accNo the account number
     * @param accountName the username associated with the account
     * @param ibanNo the International Bank Account Number (IBAN)
     * @param  BICCode the bank identifier code 
     */
	
 
	public AccountDto()
	{
		
	}

	public AccountDto(int accNo, String bICCode, int sortCode, String currency, String accountName, String country,
			String baseCurrency, String ibanNo) {
		super();
		this.accNo = accNo;
		BICCode = bICCode;
		this.sortCode = sortCode;
		this.currency = currency;
		this.accountName = accountName;
		this.country = country;
		this.baseCurrency = baseCurrency;
		this.ibanNo = ibanNo;
	}

	public int getAccNo() {
		return accNo;
	}

	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}

	public String getBICCode() {
		return BICCode;
	}

	public void setBICCode(String bICCode) {
		BICCode = bICCode;
	}

	public int getSortCode() {
		return sortCode;
	}

	public void setSortCode(int sortCode) {
		this.sortCode = sortCode;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getBaseCurrency() {
		return baseCurrency;
	}

	public void setBaseCurrency(String baseCurrency) {
		this.baseCurrency = baseCurrency;
	}

	public String getIbanNo() {
		return ibanNo;
	}

	public void setIbanNo(String ibanNo) {
		this.ibanNo = ibanNo;
	}
 
	
}
 
