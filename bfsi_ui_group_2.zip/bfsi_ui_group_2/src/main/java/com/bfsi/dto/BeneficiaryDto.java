package com.bfsi.dto;

import java.io.Serializable;

/*
 * 	This class represents a Data Transfer Object (DTO) for a Beneficiary.
 *  This BeneficiaryDto class contains all the Beneficiary table fields.
 */

public class BeneficiaryDto implements Serializable
{
 
private int beneficiaryId;
	
	private String beneficiaryName;
	
	private String accountNo;
	
	private String beneficiaryCode;
	
	private String beneficiaryCdiRef;

	/*
     * Constructs a new BeneficiaryDto with the specified ID and name.
     * beneficiaryId the unique identifier for the beneficiary
     * beneficiarName the name of the beneficiary
     */
	public BeneficiaryDto(int beneficiaryId, String beneficiaryName, String accountNo, String beneficiaryCode,
			String beneficiaryCdiRef) {
		super();
		this.beneficiaryId = beneficiaryId;
		this.beneficiaryName = beneficiaryName;
		this.accountNo = accountNo;
		this.beneficiaryCode = beneficiaryCode;
		this.beneficiaryCdiRef = beneficiaryCdiRef;
	}
	
	public BeneficiaryDto()
	{
		
	}
	
	/*
	 * All Getters and setters of this class
	 */
	public int getBeneficiaryId() {
		return beneficiaryId;
	}

	public void setBeneficiaryId(int beneficiaryId) {
		this.beneficiaryId = beneficiaryId;
	}

	public String getBeneficiaryName() {
		return beneficiaryName;
	}

	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getBeneficiaryCode() {
		return beneficiaryCode;
	}

	public void setBeneficiaryCode(String beneficiaryCode) {
		this.beneficiaryCode = beneficiaryCode;
	}

	public String getBeneficiaryCdiRef() {
		return beneficiaryCdiRef;
	}

	public void setBeneficiaryCdiRef(String beneficiaryCdiRef) {
		this.beneficiaryCdiRef = beneficiaryCdiRef;
	}

	/*
     * Returns a string representation of the BeneficiaryEntity.
     */
	@Override
	public String toString() {
		return "BeneficiaryEntity [beneficiaryId=" + beneficiaryId + ", beneficiaryName=" + beneficiaryName
				+ ", accountNo=" + accountNo + ", beneficiaryCode=" + beneficiaryCode + ", beneficiaryCdiRef="
				+ beneficiaryCdiRef + "]";
	}
	
}
 

