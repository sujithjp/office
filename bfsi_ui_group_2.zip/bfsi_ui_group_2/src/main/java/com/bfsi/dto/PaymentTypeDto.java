package com.bfsi.dto;

import java.io.Serializable;

/*
 * The PaymentTypeDto class represents a Data Transfer Object (DTO) for payment types.
 * It implements the Serializable interface to allow objects of this class to be serialized.
 * This class contains information about the payment ID, payment type, and service.
 * This class have  constructors and getters, setters.
 */
public class PaymentTypeDto implements Serializable
{
 
	private int paymentId;
	private String paymentType;
	private String service;	
	
	public PaymentTypeDto()
	{
		
	}
 
	public PaymentTypeDto(int paymentId,String paymentType, String service)
	{
		this.paymentId = paymentId;
		this.paymentType = paymentType;
		this.service = service;
	}
 
	
	public int getPaymentId()
	{
		return paymentId;
	}
 
	public void setPaymentId(int paymentId)
	{
		this.paymentId = paymentId;
	}
 
	public String getPaymentType()
	{
		return paymentType;
	}
 
	public void setPaymentType(String paymentType)
	{
		this.paymentType = paymentType;
	}
 
	public String getService()
	{
		return service;
	}
 
	public void setService(String service)
	{
		this.service = service;
	}
}
 
