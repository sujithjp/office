package com.bfsi.payment;
import java.io.Serializable;
import java.time.LocalDate;

/*
* The PaymentsCriteriaDTO class represents the criteria for filtering payments.
* It implements the Serializable interface to allow objects of this class to be serialized.
* This class contains information about the status, batch, customer batch reference, file name, and date range.
*/

public class PaymentsCriteriaDTO implements Serializable
{
    private static final long serialVersionUID = 1448420918911911488L;

	    private int paymentId;
	    
	    private LocalDate fromDate;

	    private LocalDate toDate;

	    private int amountTransfer;

	    private String transferCurrency;

	    private String submisionMethod;

	    private String status;

	    private int batchId;

	    private String customerBatchRef;

	    private String fileName;

	    public PaymentsCriteriaDTO() {}


         public PaymentsCriteriaDTO(LocalDate fromDate, LocalDate toDate,String status,int batchId,String customerBatchRef,String fileName) {
        	 this.fromDate = fromDate;
        	 this.toDate = toDate;
        	 this.status = status;
        	 this.batchId = batchId;
        	 this.customerBatchRef=customerBatchRef;
        	 this.fileName = fileName;
        
         }


	    // Getters and Setters for all fields
	    public int getPaymentId() {
	        return paymentId;
	    }

	    public void setPaymentId(int paymentId) {
	        this.paymentId = paymentId;
	    }

		public LocalDate getFromDate() {
			return fromDate;
		}

		public void setFromDate(LocalDate fromDate) {
			this.fromDate = fromDate;
		}

		public LocalDate getToDate() {
			return toDate;
		}

		public void setToDate(LocalDate toDate) {
			this.toDate = toDate;
		}

		public int getAmountTransfer() {
	        return amountTransfer;
	    }

	    public void setAmountTransfer(int amountTransfer) {
	        this.amountTransfer = amountTransfer;
	    }

	    public String getTransferCurrency() {
	        return transferCurrency;
	    }

	    public void setTransferCurrency(String transferCurrency) {
	        this.transferCurrency = transferCurrency;
	    }

	    public String getSubmisionMethod() {
	        return submisionMethod;
	    }

	    public void setSubmisionMethod(String submisionMethod) {
	        this.submisionMethod = submisionMethod;
	    }

	    public String getStatus() {
	        return status;
	    }

	    public void setStatus(String status) {
	        this.status = status;
	    }

	
	    public int getBatchId() {
			return batchId;
		}

		public void setBatchId(int batchId) {
			this.batchId = batchId;
		}

		public String getCustomerBatchRef() {
			return customerBatchRef;
		}

		public void setCustomerBatchRef(String customerBatchRef) {
			this.customerBatchRef = customerBatchRef;
		}

		public String getFileName() {
			return fileName;
		}

		public void setFileName(String fileName) {
			this.fileName = fileName;
		}

		@Override
		public String toString() {
			return "PaymentsCriteriaDTO [paymentId=" + paymentId + ", fromDate=" + fromDate + ", toDate=" + toDate
					+ ", amountTransfer=" + amountTransfer + ", transferCurrency=" + transferCurrency
					+ ", submisionMethod=" + submisionMethod + ", status=" + status + ", batchId=" + batchId
					+ ", customerBatchRef=" + customerBatchRef + ", fileName=" + fileName + "]";
		}
		
		
}

