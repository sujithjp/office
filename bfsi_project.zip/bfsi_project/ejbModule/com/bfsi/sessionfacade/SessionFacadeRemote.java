package com.bfsi.sessionfacade;
import java.util.List;
import javax.ejb.Remote;
import com.bfsi.payment.PaymentsCriteriaDTO;
import com.bfsi.dto.AccountDto;
import com.bfsi.dto.BeneficiaryDto;
import com.bfsi.dto.PaymentDto;
import com.bfsi.dto.PaymentTypeDto;

/*
 * The SessionFacadeRemote interface provides remote access to various session facade methods.
 * It includes methods for retrieving beneficiaries, payment lists, payment types, account lists, ad-hoc beneficiaries, and searching payments based on criteria.
 */

@Remote
public interface SessionFacadeRemote {
    
	/*
     * Retrieves the beneficiary information.
     */
	public List<BeneficiaryDto> getBeneficiary();
	
	/*
     * Retrieves a list of payment DTOs.
     * returns a list of PaymentDto objects
     */
	public List<PaymentDto> getPaymentList();
	
	/*
     * Retrieves a list of payment type DTOs. 
     * returns a list of PaymentTypeDto objects
     */
	public List<PaymentTypeDto> getPaymentType();
	
	/*
     * Retrieves the accounts list.
     */
	
    public List<AccountDto> getAllAccounts();
    /*
     * Retrieves ad-hoc beneficiary information.
     */
    public void getAdHocBeneficiary();
    public List<PaymentDto> searchingPayments(PaymentsCriteriaDTO criteria);
    public void createPayment(PaymentDto dtoObjectCreatePayment);

}
