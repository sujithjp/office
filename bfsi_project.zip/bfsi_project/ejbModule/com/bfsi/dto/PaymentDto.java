package com.bfsi.dto;

import java.io.Serializable;
import java.time.LocalDate;

/*
* This class represents a Data Transfer Object [DTO] for a Payment.
* It implements Serializable for object serialization.
*/

public class PaymentDto implements Serializable{

    private static final long serialVersionUID = 1L; 

    private int paymentId;

    private LocalDate date_created;

    private int amountTransfer;

    private String transferCurrency;

    private String submisionMethod;

    private String status;

    private int batchId;

    private String customerBatchRef;

    private String fileName;

    public PaymentDto() {}

    /*
     * Constructs a new PaymentDto with the specified details.
     * paymentId the unique identifier for the payment
     * dateCreated the date when the payment was created
     * amountTransfer the amount of money transferred
     * paymentStatus the status of the payment
     * transferCurrency the currency used for the transfer currency
     * submisionMethod the method used for submission
     */
    
    public PaymentDto(LocalDate date_created, int amountTransfer, 
                   String transferCurrency, String submisionMethod, String status,
                   int batchId, String customerBatchRef, String fileName) {
        this.date_created = date_created;
        this.amountTransfer = amountTransfer;
        this.transferCurrency = transferCurrency;
        this.submisionMethod = submisionMethod;
        this.status = status;
        this.batchId = batchId;
        this.customerBatchRef = customerBatchRef;
        this.fileName = fileName;
    }

    // Getters and Setters for all fields
    public int getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(int paymentId) {
        this.paymentId = paymentId;
    }

 
    public LocalDate getDate_created() {
		return date_created;
	}

	public void setDate_created(LocalDate date_created) {
		this.date_created = date_created;
	}

	public int getAmountTransfer() {
        return amountTransfer;
    }

    public void setAmountTransfer(int amountTransfer) {
        this.amountTransfer = amountTransfer;
    }

    public String getTransferCurrency() {
        return transferCurrency;
    }

    public void setTransferCurrency(String transferCurrency) {
        this.transferCurrency = transferCurrency;
    }

    public String getSubmisionMethod() {
        return submisionMethod;
    }

    public void setSubmisionMethod(String submisionMethod) {
        this.submisionMethod = submisionMethod;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getBatchId() {
		return batchId;
	}

	public void setBatchId(int batchId) {
		this.batchId = batchId;
	}

	public String getCustomerBatchRef() {
        return customerBatchRef;
    }

    public void setCustomerBatchRef(String customerBatchRef) {
        this.customerBatchRef = customerBatchRef;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

	@Override
	public String toString() {
		return "PaymentDto [paymentId=" + paymentId + ", date_created=" + date_created + ", amountTransfer="
				+ amountTransfer + ", transferCurrency=" + transferCurrency + ", submisionMethod=" + submisionMethod
				+ ", status=" + status + ", batchId=" + batchId + ", customerBatchRef=" + customerBatchRef
				+ ", fileName=" + fileName + "]";
	}
    
    
}
