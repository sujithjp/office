package com.ejb;

import com.bfsi.dto.*;
import com.bfsi.payment.PaymentsCriteriaDTO;
import com.bfsi.sessionfacade.SessionFacadeRemote;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import java.util.List;

@Stateless(name = "SessionFacadeService", mappedName = "SessionFacadeService")
public class SessionFacadeBean implements SessionFacadeRemote {

    @Override
    public List<BeneficiaryDto> getBeneficiary() {
        System.out.println("hello");
		return null;
    }

    @Override
    public List<PaymentDto> getPaymentList() {
        System.out.println("yes");
		return null;
    }

    @Override
    public List<PaymentTypeDto> getPaymentType() {
        System.out.println("");
		return null;
    }

    @Override
    public List<AccountDto> getAllAccounts() {
        System.out.println("hi");
		return null;
    }

    @Override
    public void getAdHocBeneficiary() {
        System.out.println("addded");
    }


    @Override
    public void createPayment(PaymentDto dtoObjectCreatePayment) {
        System.out.println("created");
    }

	@Override
	public List<PaymentDto> searchingPayments(PaymentsCriteriaDTO criteria) {
		// TODO Auto-generated method stub
		return null;
	}
}
